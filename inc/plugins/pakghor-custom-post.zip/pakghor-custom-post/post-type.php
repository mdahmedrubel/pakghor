<?php
// Connot access this file directly
if ( !defined( 'ABSPATH' ) ) { die; }
/**
 * Plugin Name: Pakghor Custom Post
 * Plugin URI: 
 * Description: This plugin is for pakghor registration and custom post type
 * Author: codexcoder
 * Author URI: 
 * Version: 1.0.1
 * Text Domain: pakghor
 */
/*******************************************************************/
// Pakghor Team  post type
/*******************************************************************/
if ( ! class_exists('PakghorTeamCustomPostType') ) :

    class PakghorTeamCustomPostType{
        public static $post_type 				= 'pakghor_team';
        public static $menu_postion_post_type  	= 7;
        public static $load_theme_text_domain   = 'pakghor';
        public static function register(){

            // Title of this Post Type

            $labels = array(
	            'name'                  => _x( 'Team Member', 'Your Team Member', 'pakghor' ),
	            'singular_name'         => _x( 'Team Member', 'Your Team Member', 'pakghor' ),
	            'menu_name'             => _x( 'Team Member', 'admin menu', 'pakghor' ),
	            'name_admin_bar'        => _x( 'Team Memebr', 'Add New on admin bar', 'pakghor' ),
	            'add_new'               => _x( 'Add New Member', 'memebr', 'pakghor' ),
	            'add_new_item'          => __( 'Add New Team Member', 'pakghor' ),
	            'new_item'              => __( 'New Team Member', 'pakghor' ),
	            'edit_item'             => __( 'Edit Member', 'pakghor' ),
	            'view_item'             => __( 'View Member', 'pakghor' ),
	            'all_items'             => __( 'All Team Members', 'pakghor' ),
	            'search_items'          => __( 'Search Team Member', 'pakghor' ),
	            'parent_item_colon'     => __( 'Parent Team Member', 'pakghor' ),
	            'not_found'             => __( 'No Member Found', 'pakghor' ),
	            'not_found_in_trash'    => __( 'No Member Found in Trash', 'pakghor'),

            );

   			// Arguments of this post type
            $args = array(
                'labels'                => $labels,
                'description'           => esc_html__('Description', 'pakghor'),
                'public'                => true,
                'publicly_queryable'    => true,
                'show_ui'               => true,
                'show_in_menu'          => true,
                'query_var'             => true,
                'rewrite'               => array( 'slug' => self::$post_type ),
                'capability_type'       => 'post',
                'has_archive'           => true,
                'hierarchical'          => false,
                'menu_position'         => self::$menu_postion_post_type,
                'menu_icon'             => 'dashicons-groups',
                'supports'              => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
            );

            $args = apply_filters( 'presscore_post_type_'. self::$post_type . '_args', $args );

            register_post_type( self::$post_type, $args );

            flush_rewrite_rules();
            // End Post type 'pakghor_team'
        }

    }

	// Team Taxonomy
	// hook into the init action and call pakghor_post_type_taxonomies when it fires
    add_action('init', 'pakghor_team_taxonomy');

   function pakghor_team_taxonomy()
   {

        $labels = array(
            'name'              => _x( 'Team Category', 'Team Category', 'pakghor' ),
            'singular_name'     => _x( 'Team Category', 'Team Category', 'pakghor' ),
            'search_items'      => __( 'Search Team Category', 'pakghor' ),
            'all_items'         => __( 'All Teams Category', 'pakghor' ),
            'parent_item'       => __( 'Parent Team Category', 'pakghor' ),
            'parent_item_colon' => __( 'Parent Team Category:', 'pakghor' ),
            'edit_item'         => __( 'Edit Team Category', 'pakghor' ),
            'update_item'       => __( 'Update Team Category', 'pakghor' ),
            'add_new_item'      => __( 'Add New Team Category', 'pakghor' ),
            'new_item_name'     => __( 'New Team Category Name', 'pakghor' ),
            'menu_name'         => __( 'Team Categories', 'pakghor' ),
        );

        $args = array(
            'hierarchical'     	=> true,
            'labels'            => $labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'public'            => true,
            'rewrite'           => array( 'slug' => 'team-category' ),
        );

        register_taxonomy('team_category', 'pakghor_team', $args );
   }

    add_action( 'init', 'team_tag_taxonomies' );
        //create two taxonomies, genres and tags for the post type "tag"
    function team_tag_taxonomies() 
    {
        // Add new taxonomy, NOT hierarchical (like tags)
        $labels = array(
            'name'                         => _x( 'Team Tags', 'taxonomy general name', 'pakghor' ),
            'singular_name'                => _x( 'Team Tag', 'taxonomy singular name', 'pakghor' ),
            'search_items'                 => __( 'Search Tags', 'pakghor' ),
            'popular_items'                => __( 'Popular Tags', 'pakghor' ),
            'all_items'                    => __( 'All Tags', 'pakghor' ),
            'parent_item'                  => null,
            'parent_item_colon'            => null,
            'edit_item'                    => __( 'Edit Team Tag', 'pakghor' ), 
            'update_item'                  => __( 'Update Team Tag', 'pakghor' ),
            'add_new_item'                 => __( 'Add New Team Tag', 'pakghor' ),
            'new_item_name'                => __( 'New Team Tag Name', 'pakghor' ),
            'separate_items_with_commas'   => __( 'Separate tags with commas', 'pakghor' ),
            'add_or_remove_items'          => __( 'Add or remove tags', 'pakghor' ),
            'choose_from_most_used'        => __( 'Choose from the most used tags', 'pakghor' ),
            'menu_name'                    => __( 'Team Tags', 'pakghor' ),
        ); 

        register_taxonomy( 'team_tag', 'pakghor_team', array(
            'hierarchical'                 => false,
            'labels'                       => $labels,
            'show_ui'                      => true,
            'update_count_callback'        => '_update_post_term_count',
            'query_var'                    => true,
            'rewrite'                      => array( 'slug' => 'team-tag' ),
            )
        );
    }

endif;

	
/*******************************************************************/
// Pakghor Services  post type
/*******************************************************************/
if ( ! class_exists('PakghorServicesCustomPostType') ) :

    class PakghorServicesCustomPostType{

        public static $post_type 				= 'pakghor_services';
        public static $menu_postion_post_type  	= 7;
        public static $load_theme_text_domain   = 'pakghor';
        public static function register(){

            // Title of this Post Type
            $labels = array(
	            'name'                  => _x('Services', 'Your Services', 'pakghor' ),
	            'singular_name'         => _x( 'Services', 'Your Services', 'pakghor' ),
	            'menu_name'             => _x( 'Services', 'admin menu', 'pakghor' ),
	            'name_admin_bar'        => _x( 'Service', 'Add New on admin bar', 'pakghor' ),
	            'add_new'               => _x( 'Add New Service', 'service', 'pakghor' ),
	            'add_new_item'          => __( 'Add New Service', 'pakghor' ),
	            'new_item'              => __( 'New Service', 'pakghor' ),
	            'edit_item'             => __( 'Edit Service', 'pakghor' ),
	            'view_item'             => __( 'View Service', 'pakghor' ),
	            'all_items'             => __( 'All Services', 'pakghor' ),
	            'search_items'          => __( 'Search Service', 'pakghor' ),
	            'parent_item_colon'     => __( 'Parent Service', 'pakghor' ),
	            'not_found'             => __( 'No Service found', 'pakghor' ),
	            'not_found_in_trash'    => __( 'No Service found in Trash', 'pakghor'),

            );

   			// Arguments of this post type
            $args = array(
                'labels'                => $labels,
                'description'           => esc_html__('Description', 'pakghor'),
                'public'                => true,
                'publicly_queryable'    => true,
                'show_ui'               => true,
                'show_in_menu'          => true,
                'query_var'             => true,
                'rewrite'               => array( 'slug' => self::$post_type ),
                'capability_type'       => 'post',
                'has_archive'           => true,
                'hierarchical'          => false,
                'menu_position'         => self::$menu_postion_post_type,
                'menu_icon'             => 'dashicons-sos',
                'supports'              => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
            );

            $args = apply_filters( 'presscore_post_type_'. self::$post_type . '_args', $args );

            register_post_type( self::$post_type, $args );

            flush_rewrite_rules();
            // End Post type 'service'
        }

    }

	// Services Taxonomy
	// Hook into the init action and call pakghor_post_type_taxonomies when it fires
    add_action('init', 'pakghor_services_taxonomy');

   function pakghor_services_taxonomy()
   {
        $labels = array(
            'name'              => _x( 'Service Category', 'Service Category', 'pakghor' ),
            'singular_name'     => _x( 'Service Category', 'Service Category', 'pakghor' ),
            'search_items'      => __( 'Search Service Category', 'pakghor' ),
            'all_items'         => __( 'All Services Categories', 'pakghor' ),
            'parent_item'       => __( 'Parent Service Category', 'pakghor' ),
            'parent_item_colon' => __( 'Parent Service Category:', 'pakghor' ),
            'edit_item'         => __( 'Edit Service Category', 'pakghor' ),
            'update_item'       => __( 'Update Service Category', 'pakghor' ),
            'add_new_item'      => __( 'Add New Service Category', 'pakghor' ),
            'new_item_name'     => __( 'New Service Category Name', 'pakghor' ),
            'menu_name'         => __( 'Service Categories', 'pakghor' ),
        );

        $args = array(
            'hierarchical'     	=> true,
            'labels'            => $labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'public'            => true,
            'rewrite'           => array( 'slug' => 'services-category' ),
        );

        register_taxonomy('services_category', 'pakghor_services', $args );
   }

    add_action( 'init', 'services_tag_taxonomies' );
        //create two taxonomies, genres and tags for the post type "tag"
    function services_tag_taxonomies() 
    {
        // Add new taxonomy, NOT hierarchical (like tags)
        $labels = array(
            'name'                         => _x( 'Services Tags', 'taxonomy general name', 'pakghor' ),
            'singular_name'                => _x( 'Services Tag', 'taxonomy singular name', 'pakghor' ),
            'search_items'                 => __( 'Search Tags', 'pakghor' ),
            'popular_items'                => __( 'Popular Tags', 'pakghor' ),
            'all_items'                    => __( 'All Tags', 'pakghor' ),
            'parent_item'                  => null,
            'parent_item_colon'            => null,
            'edit_item'                    => __( 'Edit Services Tag', 'pakghor' ), 
            'update_item'                  => __( 'Update Services Tag', 'pakghor' ),
            'add_new_item'                 => __( 'Add New Services Tag', 'pakghor' ),
            'new_item_name'                => __( 'New Services Tag Name', 'pakghor' ),
            'separate_items_with_commas'   => __( 'Separate tags with commas', 'pakghor' ),
            'add_or_remove_items'          => __( 'Add or remove tags', 'pakghor' ),
            'choose_from_most_used'        => __( 'Choose from the most used tags', 'pakghor' ),
            'menu_name'                    => __( 'Services Tags', 'pakghor' ),
        ); 

        register_taxonomy( 'services_tag', 'pakghor_services', array(
            'hierarchical'                 => false,
            'labels'                       => $labels,
            'show_ui'                      => true,
            'update_count_callback'        => '_update_post_term_count',
            'query_var'                    => true,
            'rewrite'                      => array( 'slug' => 'services-tag' ),
            )
        );
    }

endif;


/*******************************************************************/
// Pakghor Food-Gallery  post type
/*******************************************************************/
if ( ! class_exists('PakghorFoodGalleryCustomPostType') ) :

    class PakghorFoodGalleryCustomPostType{

        public static $post_type 				= 'pakghor_gallery';
        public static $menu_postion_post_type  	= 7;
        public static $load_theme_text_domain   = 'pakghor';
        public static function register(){

            // Title of this Post Type
            $labels = array(
	            'name'                  => _x( 'Food Gallery', 'Your Galleries', 'pakghor' ),
	            'singular_name'         => _x( 'Galleries', 'Your Gallery', 'pakghor' ),
	            'menu_name'             => _x( 'Food Gallery', 'admin menu', 'pakghor' ),
	            'name_admin_bar'        => _x( 'Gallery', 'Add New on admin bar', 'pakghor' ),
	            'add_new'               => _x( 'Add New Gallery', 'memebr', 'pakghor' ),
	            'add_new_item'          => __( 'Add New Gallery', 'pakghor' ),
	            'new_item'              => __( 'New Gallery', 'pakghor' ),
	            'edit_item'             => __( 'Edit Gallery', 'pakghor' ),
	            'view_item'             => __( 'View Gallery', 'pakghor' ),
	            'all_items'             => __( 'All Galleries', 'pakghor' ),
	            'search_items'          => __( 'Search Gallery', 'pakghor' ),
	            'parent_item_colon'     => __( 'Parent Gallery', 'pakghor' ),
	            'not_found'             => __( 'No Gallery found', 'pakghor' ),
	            'not_found_in_trash'    => __( 'No Gallery found in Trash', 'pakghor'),

            );

   			// Arguments of this post type
            $args = array(
                'labels'                => $labels,
                'description'           => esc_html__('Description', 'pakghor'),
                'public'                => true,
                'publicly_queryable'    => true,
                'show_ui'               => true,
                'show_in_menu'          => true,
                'query_var'             => true,
                'rewrite'               => array( 'slug' => self::$post_type ),
                'capability_type'       => 'post',
                'has_archive'           => true,
                'hierarchical'          => false,
                'menu_position'         => self::$menu_postion_post_type,
                'menu_icon'             => 'dashicons-format-gallery',
                'supports'              => array( 'title', 'editor', 'thumbnail' ),
            );

            $args = apply_filters( 'presscore_post_type_'. self::$post_type . '_args', $args );

            register_post_type( self::$post_type, $args );

            flush_rewrite_rules();
            // End Post type 'gallery'
        }

    }

	// Food gallery Taxonomy
	// Hook into the init action and call pakghor_post_type_taxonomies when it fires
    add_action('init', 'pakghor_gallery_taxonomy');

   function pakghor_gallery_taxonomy()
   {
        $labels = array(
            'name'              => _x( 'Gallery Category', 'Gallery Category', 'pakghor' ),
            'singular_name'     => _x( 'Gallery Category', 'Gallery Category', 'pakghor' ),
            'search_items'      => __( 'Search Gallery Category', 'pakghor' ),
            'all_items'         => __( 'All Galleries Categories', 'pakghor' ),
            'parent_item'       => __( 'Parent Gallery Category', 'pakghor' ),
            'parent_item_colon' => __( 'Parent Gallery Category:', 'pakghor' ),
            'edit_item'         => __( 'Edit Gallery Category', 'pakghor' ),
            'update_item'       => __( 'Update Gallery Category', 'pakghor' ),
            'add_new_item'      => __( 'Add New Gallery Category', 'pakghor' ),
            'new_item_name'     => __( 'New Gallery Category Name', 'pakghor' ),
            'menu_name'         => __( 'Gallery Categories', 'pakghor' ),
        );

        $args = array(
            'hierarchical'     	=> true,
            'labels'            => $labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'public'            => true,
            'rewrite'           => array( 'slug' => 'gallery-category' ),
        );
        register_taxonomy('gallery-category', 'pakghor_gallery', $args );
   }

       add_action( 'init', 'gallery_tag_taxonomies' );
        //create two taxonomies, genres and tags for the post type "tag"
    function gallery_tag_taxonomies() 
    {
        // Add new taxonomy, NOT hierarchical (like tags)
        $labels = array(
            'name'                         => _x( 'Gallery Tags', 'taxonomy general name', 'pakghor' ),
            'singular_name'                => _x( 'Gallery Tag', 'taxonomy singular name', 'pakghor' ),
            'search_items'                 => __( 'Search Tags', 'pakghor' ),
            'popular_items'                => __( 'Popular Tags', 'pakghor' ),
            'all_items'                    => __( 'All Tags', 'pakghor' ),
            'parent_item'                  => null,
            'parent_item_colon'            => null,
            'edit_item'                    => __( 'Edit Gallery Tag', 'pakghor' ), 
            'update_item'                  => __( 'Update Gallery Tag', 'pakghor' ),
            'add_new_item'                 => __( 'Add New Gallery Tag', 'pakghor' ),
            'new_item_name'                => __( 'New Gallery Tag Name', 'pakghor' ),
            'separate_items_with_commas'   => __( 'Separate tags with commas', 'pakghor' ),
            'add_or_remove_items'          => __( 'Add or remove tags', 'pakghor' ),
            'choose_from_most_used'        => __( 'Choose from the most used tags', 'pakghor' ),
            'menu_name'                    => __( 'Gallery Tags', 'pakghor' ),
        ); 

        register_taxonomy( 'gallery-tag', 'pakghor_gallery', array(
            'hierarchical'                 => false,
            'labels'                       => $labels,
            'show_ui'                      => true,
            'update_count_callback'        => '_update_post_term_count',
            'query_var'                    => true,
            'rewrite'                      => array( 'slug' => 'gallery-tag' ),
            )
        );
    }

endif;


/*******************************************************************/
// Pakghor Event  post type
/*******************************************************************/
if ( !class_exists('PakghorEventCustomPostType') ) :

    class PakghorEventCustomPostType{

        public static $post_type                = 'pakghor_event';
        public static $menu_postion_post_type   = 7;
        public static $load_theme_text_domain   = 'pakghor';
        public static function register(){

            // Title of this Post Type
            $labels = array(
                'name'                  => _x( 'Event', 'Your Event', 'pakghor' ),
                'singular_name'         => _x( 'Events', 'Your Event', 'pakghor' ),
                'menu_name'             => _x( 'Events', 'admin menu', 'pakghor' ),
                'name_admin_bar'        => _x( 'Events', 'Add New on admin bar', 'pakghor' ),
                'add_new'               => _x( 'Add New Event', 'event', 'pakghor' ),
                'add_new_item'          => __( 'Add New Event', 'pakghor' ),
                'new_item'              => __( 'New Event', 'pakghor' ),
                'edit_item'             => __( 'Edit Event', 'pakghor' ),
                'view_item'             => __( 'View Event', 'pakghor' ),
                'all_items'             => __( 'All Events', 'pakghor' ),
                'search_items'          => __( 'Search Event', 'pakghor' ),
                'parent_item_colon'     => __( 'Parent Event', 'pakghor' ),
                'not_found'             => __( 'No Event found', 'pakghor' ),
                'not_found_in_trash'    => __( 'No Event found in Trash', 'pakghor'),

            );

            // Arguments of this post type
            $args = array(
                'labels'                => $labels,
                'description'           => esc_html__('Description', 'pakghor'),
                'public'                => true,
                'publicly_queryable'    => true,
                'show_ui'               => true,
                'show_in_menu'          => true,
                'query_var'             => true,
                'rewrite'               => array( 'slug' => self::$post_type ),
                'capability_type'       => 'post',
                'has_archive'           => true,
                'hierarchical'          => false,
                'menu_position'         => self::$menu_postion_post_type,
                'menu_icon'             => 'dashicons-calendar-alt',
                'supports'              => array( 'title', 'editor', 'thumbnail', 'excerpt','comments', 'author' ),
            );

            $args = apply_filters( 'presscore_post_type_'. self::$post_type . '_args', $args );

            register_post_type( self::$post_type, $args );

            flush_rewrite_rules();
            // End Post type 'Event'
        }

    }

    // Event Taxonomy
    // Hook into the init action and call pakghor_post_type_taxonomies when it fires
    add_action('init', 'pakghor_event_taxonomy');

   function pakghor_event_taxonomy()
   {
        $labels = array(
            'name'              => _x( 'Event Category', 'Event Category', 'pakghor' ),
            'singular_name'     => _x( 'Event Category', 'Event Category', 'pakghor' ),
            'search_items'      => __( 'Search Event Category', 'pakghor' ),
            'all_items'         => __( 'All Events Categories', 'pakghor' ),
            'parent_item'       => __( 'Parent Event Category', 'pakghor' ),
            'parent_item_colon' => __( 'Parent Event Category:', 'pakghor' ),
            'edit_item'         => __( 'Edit Event Category', 'pakghor' ),
            'update_item'       => __( 'Update Event Category', 'pakghor' ),
            'add_new_item'      => __( 'Add New Event Category', 'pakghor' ),
            'new_item_name'     => __( 'New Event Category Name', 'pakghor' ),
            'menu_name'         => __( 'Event Categories', 'pakghor' ),
        );

        $args = array(
            'hierarchical'      => true,
            'labels'            => $labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'public'            => true,
            'rewrite'           => array( 'slug' => 'event-category' ),
        );

        register_taxonomy('event_category', 'pakghor_event', $args );
   }

    add_action( 'init', 'event_tag_taxonomies');
        //create two taxonomies, genres and tags for the post type "tag"
    function event_tag_taxonomies() 
    {
        // Add new taxonomy, NOT hierarchical (like tags)
        $labels = array(
            'name'                         => _x( 'Event Tags', 'taxonomy general name', 'pakghor' ),
            'singular_name'                => _x( 'Event Tag', 'taxonomy singular name', 'pakghor' ),
            'search_items'                 => __( 'Search Tags', 'pakghor' ),
            'popular_items'                => __( 'Popular Tags', 'pakghor' ),
            'all_items'                    => __( 'All Tags', 'pakghor' ),
            'parent_item'                  => null,
            'parent_item_colon'            => null,
            'edit_item'                    => __( 'Edit Event Tag', 'pakghor' ), 
            'update_item'                  => __( 'Update Event Tag', 'pakghor' ),
            'add_new_item'                 => __( 'Add New Event Tag', 'pakghor' ),
            'new_item_name'                => __( 'New Event Tag Name', 'pakghor' ),
            'separate_items_with_commas'   => __( 'Separate tags with commas', 'pakghor' ),
            'add_or_remove_items'          => __( 'Add or remove tags', 'pakghor' ),
            'choose_from_most_used'        => __( 'Choose from the most used tags', 'pakghor' ),
            'menu_name'                    => __( 'Event Tags', 'pakghor' ),
        ); 

        register_taxonomy( 'event_tag', 'pakghor_event', array(
            'hierarchical'                 => false,
            'labels'                       => $labels,
            'show_ui'                      => true,
            'update_count_callback'        => '_update_post_term_count',
            'query_var'                    => true,
            'rewrite'                      => array( 'slug' => 'event-tag' ),
            )
        );
    }

endif;  // End the Class

    
/*******************************************************************/
// Pakghor Testimonial  post type
/*******************************************************************/
if ( !class_exists('PakghorTestimonialCustomPostType') ) :

    class PakghorTestimonialCustomPostType{

        public static $post_type                = 'pakghor_testimonial';
        public static $menu_postion_post_type   = 7;
        public static $load_theme_text_domain   = 'pakghor';
        public static function register(){

            // Title of this Post Type
            $labels = array(
                'name'                  => _x( 'Testimonial', 'Your Testimonial', 'pakghor' ),
                'singular_name'         => _x( 'Testimonials', 'Your Testimonial', 'pakghor' ),
                'menu_name'             => _x( 'Testimonial', 'admin menu', 'pakghor' ),
                'name_admin_bar'        => _x( 'Testimonial', 'Add New on admin bar', 'pakghor' ),
                'add_new'               => _x( 'Add New Testimonial', 'testimonial', 'pakghor' ),
                'add_new_item'          => __( 'Add New Testimonial', 'pakghor' ),
                'new_item'              => __( 'New Testimonial', 'pakghor' ),
                'edit_item'             => __( 'Edit Testimonial', 'pakghor' ),
                'view_item'             => __( 'View Testimonial', 'pakghor' ),
                'all_items'             => __( 'All Testimonials', 'pakghor' ),
                'search_items'          => __( 'Search Testimonial', 'pakghor' ),
                'parent_item_colon'     => __( 'Parent Testimonial', 'pakghor' ),
                'not_found'             => __( 'No Testimonial found', 'pakghor' ),
                'not_found_in_trash'    => __( 'No Testimonial found in Trash', 'pakghor'),

            );

            // Arguments of this post type
            $args = array(
                'labels'                => $labels,
                'description'           => esc_html__('Description', 'pakghor'),
                'public'                => true,
                'publicly_queryable'    => true,
                'show_ui'               => true,
                'show_in_menu'          => true,
                'query_var'             => true,
                'rewrite'               => array( 'slug' => self::$post_type ),
                'capability_type'       => 'post',
                'has_archive'           => true,
                'hierarchical'          => false,
                'menu_position'         => self::$menu_postion_post_type,
                'menu_icon'             => 'dashicons-testimonial',
                'supports'              => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
            );

            $args = apply_filters( 'presscore_post_type_'. self::$post_type . '_args', $args );

            register_post_type( self::$post_type, $args );

            flush_rewrite_rules();
            // End Post type 'testimonial'
        }

    }

    // Food testimonial Taxonomy
    // Hook into the init action and call pakghor_post_type_taxonomies when it fires
    add_action('init', 'pakghor_testimonial_taxonomy');

   function pakghor_testimonial_taxonomy()
   {
        $labels = array(
            'name'              => _x( 'Testimonial Category', 'Testimonial Category', 'pakghor' ),
            'singular_name'     => _x( 'Testimonial Category', 'Testimonial Category', 'pakghor' ),
            'search_items'      => __( 'Search Testimonial Category', 'pakghor' ),
            'all_items'         => __( 'All Testimonials Categories', 'pakghor' ),
            'parent_item'       => __( 'Parent Testimonial Category', 'pakghor' ),
            'parent_item_colon' => __( 'Parent Testimonial Category:', 'pakghor' ),
            'edit_item'         => __( 'Edit Testimonial Category', 'pakghor' ),
            'update_item'       => __( 'Update Testimonial Category', 'pakghor' ),
            'add_new_item'      => __( 'Add New Testimonial Category', 'pakghor' ),
            'new_item_name'     => __( 'New Testimonial Category Name', 'pakghor' ),
            'menu_name'         => __( 'Testimonial Categories', 'pakghor' ),
        );

        $args = array(
            'hierarchical'      => true,
            'labels'            => $labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'public'            => true,
            'rewrite'           => array( 'slug' => 'testimonial-category' ),
        );
        register_taxonomy('testimonial_category', 'pakghor_testimonial', $args);
   }

    add_action( 'init', 'testimonial_tag_taxonomies');
        //create two taxonomies, genres and tags for the post type "tag"
    function testimonial_tag_taxonomies() 
    {
        // Add new taxonomy, NOT hierarchical (like tags)
        $labels = array(
            'name'                         => _x( 'Testimonial Tags', 'taxonomy general name', 'pakghor' ),
            'singular_name'                => _x( 'Testimonial Tag', 'taxonomy singular name', 'pakghor' ),
            'search_items'                 => __( 'Search Tags', 'pakghor' ),
            'popular_items'                => __( 'Popular Tags', 'pakghor' ),
            'all_items'                    => __( 'All Tags', 'pakghor' ),
            'parent_item'                  => null,
            'parent_item_colon'            => null,
            'edit_item'                    => __( 'Edit Testimonial Tag', 'pakghor' ), 
            'update_item'                  => __( 'Update Testimonial Tag', 'pakghor' ),
            'add_new_item'                 => __( 'Add New Testimonial Tag', 'pakghor' ),
            'new_item_name'                => __( 'New Testimonial Tag Name', 'pakghor' ),
            'separate_items_with_commas'   => __( 'Separate tags with commas', 'pakghor' ),
            'add_or_remove_items'          => __( 'Add or remove tags', 'pakghor' ),
            'choose_from_most_used'        => __( 'Choose from the most used tags', 'pakghor' ),
            'menu_name'                    => __( 'Testimonial Tags', 'pakghor' ),
        ); 

        register_taxonomy( 'testimonial_tag', 'pakghor_testimonial', array(
            'hierarchical'                 => false,
            'labels'                       => $labels,
            'show_ui'                      => true,
            'update_count_callback'        => '_update_post_term_count',
            'query_var'                    => true,
            'rewrite'                      => array( 'slug' => 'testimonial-tag' ),
            )
        );
    }

endif;



/*******************************************************************/
// Pakghor Pricing  post type
/*******************************************************************/
if ( !class_exists('PakghorPricingCustomPostType') ) :

    class PakghorPricingCustomPostType{

        public static $post_type                = 'pakghor_pricing';
        public static $menu_postion_post_type   = 7;
        public static $load_theme_text_domain   = 'pakghor';
        public static function register(){

            // Title of this Post Type
            $labels = array(
                'name'                  => _x( 'Pricing Table', 'Your Pricing Table', 'pakghor' ),
                'singular_name'         => _x( 'Pricing Tables', 'Your Pricing Table', 'pakghor' ),
                'menu_name'             => _x( 'Pricing Table', 'admin menu', 'pakghor' ),
                'name_admin_bar'        => _x( 'Pricing Table', 'Add New on admin bar', 'pakghor' ),
                'add_new'               => _x( 'Add New Pricing Table', 'Pricing Table', 'pakghor' ),
                'add_new_item'          => __( 'Add New Pricing Table', 'pakghor' ),
                'new_item'              => __( 'New Pricing Table', 'pakghor' ),
                'edit_item'             => __( 'Edit Pricing Table', 'pakghor' ),
                'view_item'             => __( 'View Pricing Table', 'pakghor' ),
                'all_items'             => __( 'All Pricing Tables', 'pakghor' ),
                'search_items'          => __( 'Search Pricing Table', 'pakghor' ),
                'parent_item_colon'     => __( 'Parent Pricing Table', 'pakghor' ),
                'not_found'             => __( 'No Pricing Table found', 'pakghor' ),
                'not_found_in_trash'    => __( 'No Pricing Table found in Trash', 'pakghor'),

            );

            // Arguments of this post type
            $args = array(
                'labels'                => $labels,
                'description'           => esc_html__('Description', 'pakghor'),
                'public'                => true,
                'publicly_queryable'    => true,
                'show_ui'               => true,
                'show_in_menu'          => true,
                'query_var'             => true,
                'rewrite'               => array( 'slug' => self::$post_type ),
                'capability_type'       => 'post',
                'has_archive'           => true,
                'hierarchical'          => false,
                'menu_position'         => self::$menu_postion_post_type,
                'menu_icon'             => 'dashicons-list-view',
                'supports'              => array( 'title', 'editor', 'thumbnail' ),
            );

            $args = apply_filters( 'presscore_post_type_'. self::$post_type . '_args', $args );

            register_post_type( self::$post_type, $args );

            flush_rewrite_rules();
            // End Post type 'prcicing'
        }

    }

    // Food Pricing Taxonomy
    // Hook into the init action and call pakghor_post_type_taxonomies when it fires
    add_action('init', 'pakghor_pricing_taxonomy');

   function pakghor_pricing_taxonomy()
   {
        $labels = array(
            'name'              => _x( 'Pricing Table Category', 'Pricing Table Category', 'pakghor' ),
            'singular_name'     => _x( 'Pricing Table Category', 'Pricing Table Category', 'pakghor' ),
            'search_items'      => __( 'Search Pricing Table Category', 'pakghor' ),
            'all_items'         => __( 'All Pricing Tables Categories', 'pakghor' ),
            'parent_item'       => __( 'Parent Pricing Table Category', 'pakghor' ),
            'parent_item_colon' => __( 'Parent Pricing Table Category:', 'pakghor' ),
            'edit_item'         => __( 'Edit Pricing Table Category', 'pakghor' ),
            'update_item'       => __( 'Update Pricing Table Category', 'pakghor' ),
            'add_new_item'      => __( 'Add New Pricing Table Category', 'pakghor' ),
            'new_item_name'     => __( 'New Pricing Table Category Name', 'pakghor' ),
            'menu_name'         => __( 'Pricing Categories', 'pakghor' ),
        );

        $args = array(
            'hierarchical'      => true,
            'labels'            => $labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'public'            => true,
            'rewrite'           => array( 'slug' => 'pricing-category' ),
        );
        register_taxonomy('pricing_category', 'pakghor_pricing', $args );
   }

   add_action( 'init', 'pricing_tag_taxonomies');
        //create two taxonomies, genres and tags for the post type "tag"
    function pricing_tag_taxonomies() 
    {
        // Add new taxonomy, NOT hierarchical (like tags)
        $labels = array(
            'name'                         => _x( 'Pricing Tags', 'taxonomy general name', 'pakghor' ),
            'singular_name'                => _x( 'Pricing Tag', 'taxonomy singular name', 'pakghor' ),
            'search_items'                 => __( 'Search Tags', 'pakghor' ),
            'popular_items'                => __( 'Popular Tags', 'pakghor' ),
            'all_items'                    => __( 'All Tags', 'pakghor' ),
            'parent_item'                  => null,
            'parent_item_colon'            => null,
            'edit_item'                    => __( 'Edit Pricing Tag', 'pakghor' ), 
            'update_item'                  => __( 'Update Pricing Tag', 'pakghor' ),
            'add_new_item'                 => __( 'Add New Pricing Tag', 'pakghor' ),
            'new_item_name'                => __( 'New Pricing Tag Name', 'pakghor' ),
            'separate_items_with_commas'   => __( 'Separate tags with commas', 'pakghor' ),
            'add_or_remove_items'          => __( 'Add or remove tags', 'pakghor' ),
            'choose_from_most_used'        => __( 'Choose from the most used tags', 'pakghor' ),
            'menu_name'                    => __( 'Pricing Tags', 'pakghor' ),
        ); 

        register_taxonomy( 'pricing_tag', 'pakghor_pricing', array(
            'hierarchical'                 => false,
            'labels'                       => $labels,
            'show_ui'                      => true,
            'update_count_callback'        => '_update_post_term_count',
            'query_var'                    => true,
            'rewrite'                      => array( 'slug' => 'pricing-tag' ),
            )
        );
    }

endif;

	/////////////////////////
	// Register all posts types
	/////////////////////////

	add_action( 'init', 'pakghor_all_custom_post_type_register', 10 );
	if( !function_exists('pakghor_all_custom_post_type_register') )
	{
	   function pakghor_all_custom_post_type_register()
       {
	        PakghorTeamCustomPostType::register();
	        PakghorServicesCustomPostType::register();
            PakghorFoodGalleryCustomPostType::register();
            PakghorEventCustomPostType::register();
            PakghorTestimonialCustomPostType::register();
	        PakghorPricingCustomPostType::register();
	    }
	}