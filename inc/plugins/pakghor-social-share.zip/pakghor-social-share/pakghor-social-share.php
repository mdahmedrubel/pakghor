<?php
/**
 * Plugin Name: Pakghor Social Share
 * Plugin URI: 
 * Description: This plugin is for Pakghor Social Share
 * Author: CodexCoder
 * Author URI: 
 * Version: 1.0.0
 * Text Domain: pakghor
 */
 
// Blog Social Share
if( !function_exists('pakghor_blog_social_share') ): 
    function pakghor_blog_social_share(){ 
        global $post_id; ?>
        <ul>
            <li><?php esc_html_e('Share This Post:','pakghor') ?></li>
           <?php $pinterest_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post_id), 'full' ); ?>
            <li><a href="https://www.facebook.com/share.php?u=<?php echo urlencode( get_permalink( $post_id ) ); ?>"><i class="fa fa-facebook"></i></a></li>
            <li><a href="https://twitter.com/home?status=<?php the_title() ?> <?php echo urlencode( get_permalink( $post_id ) ); ?>"><i class="fa fa-twitter"></i></a></li>
            <li><a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo urlencode( get_permalink( $post_id ) ); ?>&title=<?php the_title(); ?>"><i class="fa fa-linkedin"></i></a></li>
            <li><a href="https://plus.google.com/share?url=<?php echo urlencode( get_permalink( $post_id ) ); ?>"><i class="fa fa-google-plus"></i></a></li>
        </ul>
    <?php } 
endif;

// Event Social Share
if( !function_exists('pakghor_event_social_share') ): 
    function pakghor_event_social_share(){ 
        global $post_id; ?>
        <ul>
            <li><?php esc_html_e('Share This Event:','pakghor'); ?></li>
           <?php $pinterest_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post_id), 'full' ); ?>
            <li><a href="https://www.facebook.com/share.php?u=<?php echo urlencode( get_permalink( $post_id ) ); ?>"><i class="fa fa-facebook"></i></a></li>
            <li><a href="https://twitter.com/home?status=<?php the_title() ?> <?php echo urlencode( get_permalink( $post_id ) ); ?>"><i class="fa fa-twitter"></i></a></li>
            <li><a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo urlencode( get_permalink( $post_id ) ); ?>&title=<?php the_title(); ?>"><i class="fa fa-linkedin"></i></a></li>
            <li><a href="https://plus.google.com/share?url=<?php echo urlencode( get_permalink( $post_id ) ); ?>"><i class="fa fa-google-plus"></i></a></li>
        </ul>
    <?php }
endif;











